This system is totally written by d3.js, and the .html file could be run directly by double clicking it.

In the system, a geo_map with temperature is shown. Place the mouse over it can see information on each position by text-box and also on the top-right. 
By clicking it, a position is selected and information is shown on the top-left for comparison.
A legend on the right shows the color scale for temperature and a moving line will be shown if placing the mouse to some position in the heatmap.
There is a time slider on the top to select a certain time.
There is a selection at the bottom to select which measurement to be shown for the heatmap, temperature or humidity.

There are three line plots at the bottom showing how information change across time. Clicking certain positions on the heatmap would change the line curve.

There are three scatter plots at the bottom showing lat, lng and wnd.